class Retirement < ActiveRecord::Base
  belongs_to :user
end
